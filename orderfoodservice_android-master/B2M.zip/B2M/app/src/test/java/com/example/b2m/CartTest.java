package com.example.b2m;

import static org.junit.Assert.*;

public class CartTest {

}