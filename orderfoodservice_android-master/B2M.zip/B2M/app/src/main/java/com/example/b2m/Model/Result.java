package com.example.b2m.Model;

class Result {
    public String message_id;
}
