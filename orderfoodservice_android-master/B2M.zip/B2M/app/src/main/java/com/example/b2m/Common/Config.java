package com.example.b2m.Common;

public class Config {
    public static final String PAYPAL_CLIENT_ID = "AUVR7BG3i-Lt6mUUuuy203M8eYj_gLHxhajc4xNr7W2xFMVG1B6pvLKwRz8LddlCbBbXodWm9EgeNTQ0";
    //public static final String PAYPAL_CLIENT_ID = "AcU5tN6dsJioa4q51NCbjJRw6KMk6hUMjd7oQ9sgwRonoi6ux5aPqK-IFQt7alO-rNGPuyZEdfcfrj65";

}
